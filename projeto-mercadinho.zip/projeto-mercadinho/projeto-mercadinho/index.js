const express = require('express');
const app = express();

app.get('/',async(req,res) => {
    res.send('Página Inicial');
});

app.listen(8094, () => {
    console.log(`Servidor iniciado na porta ${8094}`);
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname,'src','index.html'));
});