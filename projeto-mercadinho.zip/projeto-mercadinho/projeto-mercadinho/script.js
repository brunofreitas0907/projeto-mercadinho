// Smooth animations on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Sample data for demonstration
let sampleProducts = [
    { id: 'PRD001', name: 'MacBook Pro 16"', category: 'Eletrônicos', price: 15999.00, stock: 45, stockLevel: 'high', icon: '💻' },
    { id: 'PRD002', name: 'iPhone 15 Pro Max', category: 'Smartphones', price: 9499.00, stock: 12, stockLevel: 'medium', icon: '📱' },
    { id: 'PRD003', name: 'AirPods Pro', category: 'Acessórios', price: 2299.00, stock: 5, stockLevel: 'low', icon: '🎧' }
];

// Render sample products
function renderProducts() {
    const tbody = document.getElementById('productsTableBody');
    if (sampleProducts.length > 0) {
        tbody.innerHTML = sampleProducts.map(product => `
            <tr>
                <td><div class="product-info"><div class="product-image">${product.icon}</div><div class="product-details"><span class="product-name">${product.name}</span><span class="product-sku">SKU: ${product.id}</span></div></div></td>
                <td><span class="category-badge">${product.category}</span></td>
                <td><span class="price">R$ ${product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></td>
                <td><div class="stock-indicator"><span class="stock-value">${product.stock}</span><div class="stock-bar"><div class="stock-fill ${product.stockLevel}"></div></div></div></td>
                <td><span class="category-badge" style="background: ${product.stockLevel === 'high' ? 'rgba(16, 185, 129, 0.1)' : product.stockLevel === 'medium' ? 'rgba(245, 158, 11, 0.1)' : 'rgba(239, 68, 68, 0.1)'}; color: ${product.stockLevel === 'high' ? '#10b981' : product.stockLevel === 'medium' ? '#f59e0b' : '#ef4444'}; border-color: ${product.stockLevel === 'high' ? 'rgba(16, 185, 129, 0.2)' : product.stockLevel === 'medium' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(239, 68, 68, 0.2)'};">${product.stockLevel === 'high' ? 'Em Estoque' : product.stockLevel === 'medium' ? 'Estoque Médio' : 'Estoque Baixo'}</span></td>
                <td><div class="actions"><button class="action-btn edit" onclick="editarProduto('${product.id}')">Editar</button><button class="action-btn delete" onclick="excluirProduto('${product.id}')">Excluir</button></div></td>
            </tr>
        `).join('');
    } else {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 20px;">Nenhum produto encontrado.</td></tr>';
    }
}

async function listarProdutos() {
    try {
        const res = await fetch("http://localhost:8094/products");
        if (!res.ok) throw new Error("Servidor não disponível");
        sampleProducts = await res.json();
        renderProducts();
    } catch (error) {
        console.log('Carregando dados de exemplo...');
        renderProducts();
    }
}

function adicionarProduto(produto) {
    // Adiciona apenas localmente (sem servidor)
    const novoProduto = {
        id: 'PRD' + String(sampleProducts.length + 1).padStart(3, '0'),
        ...produto
    };
    
    sampleProducts.push(novoProduto);
    renderProducts();
    
    document.getElementById('productModal').style.display = 'none';
    alert("Produto adicionado com sucesso!");
}

async function editarProduto(productId) {
    const product = sampleProducts.find(p => p.id === productId);
    if (!product) {
        alert("Produto não encontrado!");
        return;
    }
    document.getElementById('modalTitle').textContent = 'Editar Produto';
    document.getElementById('submitProductBtn').textContent = 'Salvar Alterações';
    document.getElementById('productName').value = product.name;
    document.getElementById('productCategory').value = product.category;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productStock').value = product.stock;
    document.getElementById('productIcon').value = product.icon || '';
    document.getElementById('productModal').style.display = 'flex';
}

async function atualizarProduto(produto) {
    try {
        const res = await fetch(`http://localhost:8094/products/${produto.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(produto)
        });
        if (!res.ok) throw new Error("Erro ao atualizar produto");
        await listarProdutos();
        document.getElementById('productModal').style.display = 'none';
        alert("Produto atualizado com sucesso!");
    } catch (err) {
        console.error(err);
        const index = sampleProducts.findIndex(p => p.id === produto.id);
        if (index !== -1) {
            sampleProducts[index] = { ...produto };
            renderProducts();
            document.getElementById('productModal').style.display = 'none';
            alert("Produto atualizado localmente!");
        }
    }
}

async function excluirProduto(productId) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        try {
            const res = await fetch(`http://localhost:8094/products/${productId}`, {
                method: "DELETE"
            });
            if (!res || !res.ok) throw new Error("Erro ao excluir produto: " + (res ? res.statusText : "Sem resposta do servidor"));
            if (typeof listarProdutos === 'function') await listarProdutos(); // Verifica se listarProdutos existe
            alert('Produto excluído com sucesso!');
        } catch (err) {
            console.error("Erro ao excluir produto:", err.message);
            const index = sampleProducts.findIndex(p => p.id === productId);
            if (index !== -1) {
                sampleProducts.splice(index, 1);
                renderProducts();
                alert('Produto excluído localmente!');
            } else {
                alert('Produto não encontrado localmente!');
            }
        }
    }
}

function toggleModal(isEdit = false) {
    const modal = document.getElementById('productModal');
    if (modal.style.display === 'flex') {
        modal.style.display = 'none';
        document.getElementById('productForm').reset();
        document.getElementById('modalTitle').textContent = 'Adicionar Novo Produto';
        document.getElementById('submitProductBtn').textContent = 'Adicionar Produto';
    } else {
        modal.style.display = 'flex';
        if (!isEdit) {
            document.getElementById('productForm').reset();
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('addProductBtn').addEventListener('click', () => toggleModal(false));
    document.getElementById('closeModalBtn').addEventListener('click', () => toggleModal(false));
    document.getElementById('productModal').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) toggleModal(false);
    });

    const productForm = document.getElementById('productForm');
    productForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const stock = parseInt(document.getElementById('productStock').value);
        const stockLevel = stock <= 5 ? 'low' : stock <= 20 ? 'medium' : 'high';
        const produto = {
            id: sampleProducts.find(p => p.name === document.getElementById('productName').value)?.id || 'PRD' + String(sampleProducts.length + 1).padStart(3, '0'),
            name: document.getElementById('productName').value,
            category: document.getElementById('productCategory').value,
            price: parseFloat(document.getElementById('productPrice').value),
            stock,
            stockLevel,
            icon: document.getElementById('productIcon').value || '📦'
        };
        if (produto.id && sampleProducts.some(p => p.id === produto.id)) {
            atualizarProduto(produto);
        } else {
            adicionarProduto(produto);
        }
    });

    listarProdutos().catch(() => {
        console.log('Carregando dados de exemplo...');
        renderProducts();
    });
});

function filtrarProdutos() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const tbody = document.getElementById('productsTableBody');

    if (!searchTerm) {
        renderProducts(); // Mostra todos os produtos se o campo estiver vazio
        return;
    }

    const filteredProducts = sampleProducts.filter(product => {
        const name = product.name.toLowerCase();
        const category = product.category.toLowerCase();
        const sku = product.id.toLowerCase();
        return name.includes(searchTerm) || category.includes(searchTerm) || sku.includes(searchTerm);
    });

    if (filteredProducts.length > 0) {
        tbody.innerHTML = filteredProducts.map(product => `
            <tr>
                <td><div class="product-info"><div class="product-image">${product.icon}</div><div class="product-details"><span class="product-name">${product.name}</span><span class="product-sku">SKU: ${product.id}</span></div></div></td>
                <td><span class="category-badge">${product.category}</span></td>
                <td><span class="price">R$ ${product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span></td>
                <td><div class="stock-indicator"><span class="stock-value">${product.stock}</span><div class="stock-bar"><div class="stock-fill ${product.stockLevel}"></div></div></div></td>
                <td><span class="category-badge" style="background: ${product.stockLevel === 'high' ? 'rgba(16, 185, 129, 0.1)' : product.stockLevel === 'medium' ? 'rgba(245, 158, 11, 0.1)' : 'rgba(239, 68, 68, 0.1)'}; color: ${product.stockLevel === 'high' ? '#10b981' : product.stockLevel === 'medium' ? '#f59e0b' : '#ef4444'}; border-color: ${product.stockLevel === 'high' ? 'rgba(16, 185, 129, 0.2)' : product.stockLevel === 'medium' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(239, 68, 68, 0.2)'};">${product.stockLevel === 'high' ? 'Em Estoque' : product.stockLevel === 'medium' ? 'Estoque Médio' : 'Estoque Baixo'}</span></td>
                <td><div class="actions"><button class="action-btn edit" onclick="editarProduto('${product.id}')">Editar</button><button class="action-btn delete" onclick="excluirProduto('${product.id}')">Excluir</button></div></td>
            </tr>
        `).join('');
    } else {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 40px; color: var(--text-secondary);">Nenhum produto encontrado para "' + searchTerm + '"</td></tr>';
    }
}

// Evento de busca
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', filtrarProdutos);
    }
});

function editProduct(id) { editarProduto(id); }
function deleteProduct(id) { excluirProduto(id); }