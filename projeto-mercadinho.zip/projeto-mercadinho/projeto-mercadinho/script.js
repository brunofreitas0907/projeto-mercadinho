
// Smooth animations on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Sample data for demonstration
const sampleProducts = [
    {
        id: 'PRD001',
        name: 'MacBook Pro 16"',
        category: 'Eletrônicos',
        price: 15999.00,
        stock: 45,
        stockLevel: 'high',
        icon: '💻'
    },
    {
        id: 'PRD002',
        name: 'iPhone 15 Pro Max',
        category: 'Smartphones',
        price: 9499.00,
        stock: 12,
        stockLevel: 'medium',
        icon: '📱'
    },
    {
        id: 'PRD003',
        name: 'AirPods Pro',
        category: 'Acessórios',
        price: 2299.00,
        stock: 5,
        stockLevel: 'low',
        icon: '🎧'
    }
];

// Render sample products
function renderProducts() {
    const tbody = document.getElementById('productsTableBody');
    
    if (sampleProducts.length > 0) {
        tbody.innerHTML = sampleProducts.map(product => `
            <tr>
                <td>
                    <div class="product-info">
                        <div class="product-image">${product.icon}</div>
                        <div class="product-details">
                            <span class="product-name">${product.name}</span>
                            <span class="product-sku">SKU: ${product.id}</span>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="category-badge">${product.category}</span>
                </td>
                <td>
                    <span class="price">R$ ${product.price.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                </td>
                <td>
                    <div class="stock-indicator">
                        <span class="stock-value">${product.stock}</span>
                        <div class="stock-bar">
                            <div class="stock-fill ${product.stockLevel}"></div>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="category-badge" 
                        style="background: ${product.stockLevel === 'high' ? 'rgba(16, 185, 129, 0.1)' 
                            : product.stockLevel === 'medium' ? 'rgba(245, 158, 11, 0.1)' 
                            : 'rgba(239, 68, 68, 0.1)'}; 
                            color: ${product.stockLevel === 'high' ? '#10b981' 
                            : product.stockLevel === 'medium' ? '#f59e0b' 
                            : '#ef4444'}; 
                            border-color: ${product.stockLevel === 'high' ? 'rgba(16, 185, 129, 0.2)' 
                            : product.stockLevel === 'medium' ? 'rgba(245, 158, 11, 0.2)' 
                            : 'rgba(239, 68, 68, 0.2)'};">
                        ${product.stockLevel === 'high' ? 'Em Estoque' 
                            : product.stockLevel === 'medium' ? 'Estoque Médio' 
                            : 'Estoque Baixo'}
                    </span>
                </td>
                <td>
                    <div class="actions">
                        <button class="action-btn edit" onclick="editProduct('${product.id}')">Editar</button>
                        <button class="action-btn delete" onclick="deleteProduct('${product.id}')">Excluir</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } else {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align:center; padding: 20px;">
                    Nenhum produto encontrado.
                </td>
            </tr>
        `;
    }
}

async function listarProdutos() {
    const res = await fetch("http//localhost/8080/products");
    const produtos = await res.json();
}

const tbody = document.getElementById("productsTableBody");
tbody.innerHTML = '';

produtos.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td>${p.name}</td>
        <td>${p.category}</td>
        <td>R$ ${p.price.toFixed(2)}</td>
        <td>${p.stock}</td>
        <td>${p.stockLevel}</td>
        <td>
    `;
    tbody.appendChild(tr);
});

async function adicionarProduto(produto) {
  try {
    const res = await fetch("http://localhost:3000/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(produto)
    });

    if (!res.ok) throw new Error("Erro ao adicionar produto");

    // Atualiza a tabela
    listarProdutos();
  } catch (err) {
    console.error(err);
    alert("Falha ao adicionar produto");
  }
}

const productForm = document.getElementById("productForm");

productForm.addEventListener("submit", (e) => {
  e.preventDefault(); // Evita que a página recarregue

  const novoProduto = {
    name: document.getElementById("productName").value,
    category: document.getElementById("productCategory").value,
    price: parseFloat(document.getElementById("productPrice").value),
    stock: parseInt(document.getElementById("productStock").value),
    stockLevel: "high", // você pode calcular depois com base no estoque
    icon: document.getElementById("productIcon").value || "📦"
  };

  adicionarProduto(novoProduto);

  // Limpa o formulário
  productForm.reset();

  // Fecha o modal (se quiser)
  document.getElementById("productModal").style.display = "none";
});



document.addEventListener("DOMContentLoaded", listarProdutos);